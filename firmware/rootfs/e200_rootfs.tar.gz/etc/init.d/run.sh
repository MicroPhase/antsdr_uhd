cd /usr/sbin
./e200 &
