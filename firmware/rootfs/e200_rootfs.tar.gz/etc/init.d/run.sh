cd /usr/sbin
./e200 &
./net_set &
